import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import EmulatorScreen from "./EmulatorScreen";
import EmulatorControls from "./EmulatorControls";

interface GameboyEmulatorProps {
  onButtonPress?: (button: string) => void;
  isGameRunning?: boolean;
  currentScore?: number;
  nextPiece?: string;
  level?: number;
  lines?: number;
}

const GameboyEmulator = ({
  onButtonPress = () => {},
  isGameRunning = false,
  currentScore = 0,
  nextPiece = "I",
  level = 0,
  lines = 0,
}: GameboyEmulatorProps) => {
  const [isPoweredOn, setIsPoweredOn] = useState(true);
  const [volume, setVolume] = useState(50);

  const handleButtonPress = (button: string) => {
    onButtonPress(button);
  };

  const togglePower = () => {
    setIsPoweredOn(!isPoweredOn);
  };

  const adjustVolume = (newVolume: number) => {
    setVolume(newVolume);
  };

  return (
    <div className="flex flex-col items-center justify-center w-full bg-gray-100">
      <Card className="relative w-[400px] h-[650px] bg-[#e0e0c0] rounded-[20px] shadow-xl border-4 border-[#a0a088] overflow-visible flex flex-col items-center pt-8 pb-6 px-6">
        {/* GameBoy Logo */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 text-center">
          <div className="text-xs font-bold text-[#333] tracking-widest">
            NINTENDO
          </div>
          <div className="text-lg font-bold text-[#333] tracking-wider">
            GAME BOY
          </div>
          <div className="text-[8px] text-[#333] tracking-wider italic">TM</div>
        </div>

        {/* Screen Area */}
        <div className="w-[320px] h-[288px] bg-[#606060] rounded-lg p-4 mb-6 shadow-inner">
          <div className="flex items-center justify-between mb-2">
            <div className="w-2 h-2 rounded-full bg-red-500"></div>
            <div className="text-xs text-white opacity-70">BATTERY</div>
          </div>
          <EmulatorScreen
            isGameRunning={isGameRunning}
            colorPalette="classic"
            onGameOver={() => {}}
            onScoreUpdate={() => {}}
          />
        </div>

        {/* Controls Area */}
        <EmulatorControls onButtonPress={handleButtonPress} />

        {/* Bottom Area */}
        <div className="absolute bottom-4 w-full flex justify-between px-8">
          <div className="flex items-center">
            <div
              className="w-8 h-8 rounded-full bg-[#404040] flex items-center justify-center cursor-pointer"
              onClick={togglePower}
            >
              <div className="text-xs text-white">⏻</div>
            </div>
            <div className="ml-2 text-xs text-[#404040]">
              {isPoweredOn ? "ON" : "OFF"}
            </div>
          </div>

          <div className="flex items-center">
            <div className="text-xs text-[#404040] mr-2">VOL</div>
            <input
              type="range"
              min="0"
              max="100"
              value={volume}
              onChange={(e) => adjustVolume(parseInt(e.target.value))}
              className="w-16 h-2 bg-[#a0a088] rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute bottom-16 right-4 text-[8px] text-[#404040] rotate-90">
          DOT MATRIX WITH STEREO SOUND
        </div>
        <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-[8px] text-[#404040]">
          © 1989 Nintendo
        </div>
      </Card>
    </div>
  );
};

export default GameboyEmulator;
