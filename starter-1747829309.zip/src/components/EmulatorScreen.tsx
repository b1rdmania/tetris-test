import React, { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";

interface EmulatorScreenProps {
  isGameRunning?: boolean;
  colorPalette?: "classic" | "blackwhite" | "blue" | "red";
  onGameOver?: () => void;
  onScoreUpdate?: (score: number) => void;
}

const EmulatorScreen = ({
  isGameRunning = false,
  colorPalette = "classic",
  onGameOver = () => {},
  onScoreUpdate = () => {},
}: EmulatorScreenProps) => {
  const [gameState, setGameState] = useState<"title" | "playing" | "gameover">(
    "title",
  );
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [lines, setLines] = useState(0);

  // Color palette configurations
  const palettes = {
    classic: {
      background: "bg-[#9bbc0f]",
      foreground: "text-[#0f380f]",
      border: "border-[#0f380f]",
      blockColor: "bg-[#0f380f]",
      screenBg: "bg-[#8bac0f]",
    },
    blackwhite: {
      background: "bg-[#e0e0e0]",
      foreground: "text-black",
      border: "border-black",
      blockColor: "bg-black",
      screenBg: "bg-[#c0c0c0]",
    },
    blue: {
      background: "bg-[#8ba5ff]",
      foreground: "text-[#00238b]",
      border: "border-[#00238b]",
      blockColor: "bg-[#00238b]",
      screenBg: "bg-[#7b95ef]",
    },
    red: {
      background: "bg-[#ff9b9b]",
      foreground: "text-[#8b0000]",
      border: "border-[#8b0000]",
      blockColor: "bg-[#8b0000]",
      screenBg: "bg-[#ef7b7b]",
    },
  };

  const currentPalette = palettes[colorPalette];

  // Mock game grid (10x20 for Tetris)
  const [grid, setGrid] = useState<number[][]>(
    Array(20)
      .fill(null)
      .map(() => Array(10).fill(0)),
  );

  // Mock tetrimino shapes for display
  const mockTetriminos = [
    // I shape
    [[1, 1, 1, 1]],
    // O shape
    [
      [1, 1],
      [1, 1],
    ],
    // T shape
    [
      [0, 1, 0],
      [1, 1, 1],
    ],
    // L shape
    [
      [1, 0],
      [1, 0],
      [1, 1],
    ],
    // J shape
    [
      [0, 1],
      [0, 1],
      [1, 1],
    ],
    // S shape
    [
      [0, 1, 1],
      [1, 1, 0],
    ],
    // Z shape
    [
      [1, 1, 0],
      [0, 1, 1],
    ],
  ];

  // Current tetrimino position and shape
  const [currentTetrimino, setCurrentTetrimino] = useState({
    shape: mockTetriminos[0],
    x: 3,
    y: 0,
  });

  // Effect to handle game state changes
  useEffect(() => {
    if (isGameRunning) {
      setGameState("playing");
      // Reset game state
      setScore(0);
      setLevel(1);
      setLines(0);
      setGrid(
        Array(20)
          .fill(null)
          .map(() => Array(10).fill(0)),
      );
      // Start with a random tetrimino
      spawnRandomTetrimino();
    } else if (gameState === "playing") {
      // Pause game logic would go here
    }
  }, [isGameRunning]);

  // Function to spawn a random tetrimino
  const spawnRandomTetrimino = () => {
    const randomIndex = Math.floor(Math.random() * mockTetriminos.length);
    setCurrentTetrimino({
      shape: mockTetriminos[randomIndex],
      x: 3,
      y: 0,
    });
  };

  // Render the title screen
  const renderTitleScreen = () => (
    <div
      className={`flex flex-col items-center justify-center h-full ${currentPalette.foreground}`}
    >
      <h1 className="text-2xl font-bold mb-4">TETRIS</h1>
      <div className="text-sm mb-6">© 1989 Nintendo</div>
      <div className="animate-pulse text-sm">PRESS START</div>
    </div>
  );

  // Render the game over screen
  const renderGameOverScreen = () => (
    <div
      className={`flex flex-col items-center justify-center h-full ${currentPalette.foreground}`}
    >
      <h1 className="text-2xl font-bold mb-4">GAME OVER</h1>
      <div className="text-sm mb-2">SCORE: {score}</div>
      <div className="text-sm mb-6">LINES: {lines}</div>
      <div className="animate-pulse text-sm">PRESS START TO PLAY AGAIN</div>
    </div>
  );

  // Render the game grid
  const renderGameGrid = () => (
    <div className="flex flex-col items-center justify-between h-full py-2">
      {/* Score display */}
      <div
        className={`w-full flex justify-between px-4 ${currentPalette.foreground} text-xs`}
      >
        <div>
          <div>SCORE</div>
          <div>{score.toString().padStart(6, "0")}</div>
        </div>
        <div>
          <div>LEVEL</div>
          <div>{level}</div>
        </div>
        <div>
          <div>LINES</div>
          <div>{lines}</div>
        </div>
      </div>

      {/* Game grid */}
      <div className={`border ${currentPalette.border} p-1 mt-2`}>
        <div className="grid grid-cols-10 gap-px">
          {grid.map((row, rowIndex) =>
            row.map((cell, colIndex) => {
              // Check if current cell is part of the active tetrimino
              const isTetriminoCell =
                rowIndex >= currentTetrimino.y &&
                rowIndex < currentTetrimino.y + currentTetrimino.shape.length &&
                colIndex >= currentTetrimino.x &&
                colIndex <
                  currentTetrimino.x + currentTetrimino.shape[0].length &&
                currentTetrimino.shape[rowIndex - currentTetrimino.y][
                  colIndex - currentTetrimino.x
                ] === 1;

              return (
                <div
                  key={`${rowIndex}-${colIndex}`}
                  className={`w-4 h-4 ${isTetriminoCell || cell === 1 ? currentPalette.blockColor : "bg-transparent"}`}
                />
              );
            }),
          )}
        </div>
      </div>

      {/* Next piece preview */}
      <div
        className={`w-full flex justify-between px-4 ${currentPalette.foreground} text-xs mt-2`}
      >
        <div>
          <div>NEXT</div>
          <div className="border border-current p-1 mt-1 w-16 h-12 flex items-center justify-center">
            {/* Placeholder for next piece */}
            <div className="grid grid-cols-4 gap-px">
              {[0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0].map(
                (cell, i) => (
                  <div
                    key={i}
                    className={`w-2 h-2 ${cell ? currentPalette.blockColor : "bg-transparent"}`}
                  />
                ),
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <Card
      className={`w-[320px] h-[288px] ${currentPalette.screenBg} overflow-hidden p-2 shadow-inner`}
    >
      {gameState === "title" && renderTitleScreen()}
      {gameState === "playing" && renderGameGrid()}
      {gameState === "gameover" && renderGameOverScreen()}
    </Card>
  );
};

export default EmulatorScreen;
