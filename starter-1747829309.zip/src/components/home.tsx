import React, { useState } from "react";
import { Card, CardContent } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import GameboyEmulator from "./GameboyEmulator";
import EmulatorOptions from "./EmulatorOptions";

const Home = () => {
  const [colorPalette, setColorPalette] = useState<
    "classic" | "blackwhite" | "modern"
  >("classic");
  const [screenSize, setScreenSize] = useState<
    "normal" | "large" | "fullscreen"
  >("normal");
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [volume, setVolume] = useState<number>(80);

  const handlePaletteChange = (
    palette: "classic" | "blackwhite" | "modern",
  ) => {
    setColorPalette(palette);
  };

  const handleScreenSizeChange = (size: "normal" | "large" | "fullscreen") => {
    setScreenSize(size);
  };

  const handleSoundToggle = (enabled: boolean) => {
    setSoundEnabled(enabled);
  };

  const handleVolumeChange = (value: number) => {
    setVolume(value);
  };

  return (
    <div className="min-h-screen w-full bg-gray-900 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-6xl">
        <h1 className="text-4xl font-bold text-center text-green-400 mb-8">
          GameBoy Tetris Emulator
        </h1>

        <div className="flex flex-col lg:flex-row gap-8 justify-center items-center">
          <div className="flex-1 flex justify-center">
            <GameboyEmulator
              colorPalette={colorPalette}
              screenSize={screenSize}
              soundEnabled={soundEnabled}
              volume={volume}
            />
          </div>

          <div className="w-full lg:w-80">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <h2 className="text-xl font-bold text-green-400 mb-4">
                  Emulator Options
                </h2>

                <Tabs defaultValue="display" className="w-full">
                  <TabsList className="grid grid-cols-2 mb-4">
                    <TabsTrigger value="display">Display</TabsTrigger>
                    <TabsTrigger value="sound">Sound</TabsTrigger>
                  </TabsList>

                  <TabsContent value="display">
                    <EmulatorOptions
                      colorPalette={colorPalette}
                      screenSize={screenSize}
                      onPaletteChange={handlePaletteChange}
                      onScreenSizeChange={handleScreenSizeChange}
                    />
                  </TabsContent>

                  <TabsContent value="sound">
                    <EmulatorOptions
                      soundEnabled={soundEnabled}
                      volume={volume}
                      onSoundToggle={handleSoundToggle}
                      onVolumeChange={handleVolumeChange}
                    />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            <div className="mt-6 p-4 bg-gray-800 border border-gray-700 rounded-lg">
              <h3 className="text-lg font-medium text-green-400 mb-2">
                Controls
              </h3>
              <ul className="text-gray-300 space-y-1 text-sm">
                <li>
                  <span className="font-bold">D-Pad:</span> Move tetrimino
                </li>
                <li>
                  <span className="font-bold">A/Up:</span> Rotate tetrimino
                </li>
                <li>
                  <span className="font-bold">B:</span> Quick drop
                </li>
                <li>
                  <span className="font-bold">Start:</span> Pause/Resume
                </li>
                <li>
                  <span className="font-bold">Select:</span> Options menu
                </li>
              </ul>
            </div>
          </div>
        </div>

        <footer className="mt-12 text-center text-gray-500 text-sm">
          <p>
            GameBoy Tetris Emulator - A pixel-perfect recreation of the classic
            game
          </p>
          <p className="mt-1">Use keyboard or on-screen controls to play</p>
        </footer>
      </div>
    </div>
  );
};

export default Home;
